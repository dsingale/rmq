package com.example.rmq_consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RmqConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(RmqConsumerApplication.class, args);
	}

}
