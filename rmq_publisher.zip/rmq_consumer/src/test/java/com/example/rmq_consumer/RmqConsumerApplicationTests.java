package com.example.rmq_consumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RmqConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
