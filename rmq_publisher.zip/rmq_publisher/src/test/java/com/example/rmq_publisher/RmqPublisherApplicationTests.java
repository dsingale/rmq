package com.example.rmq_publisher;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RmqPublisherApplicationTests {

	@Test
	void contextLoads() {
	}

}
